extern const char* gEmbeddedNNUEData;
extern const int gEmbeddedNNUESize;
