Module["onSpecialMessage"] = Module["postCustomMessage"];
